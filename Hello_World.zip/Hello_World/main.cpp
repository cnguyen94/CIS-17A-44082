/* 
 * File:   main.cpp
 * Author: Cuong Nguyen
 * Created on February 17, 2019, 10:00 AM
 * Purpose: Hello World
 */

//System Libraries

#include <iostream>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {  
    
//Output
    cout<<"Hello, World!!!"<<endl;

//Exit program
    return 0;
}

   